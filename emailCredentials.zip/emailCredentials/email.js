const email = "techshore122@gmail.com";

module.exports.email = email;
