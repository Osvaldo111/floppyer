const password = "Bringhimhome11";

module.exports.password = password;
