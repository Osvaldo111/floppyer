// The secret key
const secret_key = "PIII4aLVYa6bMdlQ208t6fbzKNm6yk6W";

exports.secret_key = secret_key;
